﻿using AdminSync.Entity.CPAdmin;
using AdminSync.Model;
using AutoMapper;

namespace AdminSync
{
    public class AutoMapperConfigurator : Profile
    {
        public AutoMapperConfigurator()
        {
            CreateMap<ClientDTO, UserData>()
                .ForMember(user => user.USER_ID, map => map.MapFrom(client => client.USER_ID))
                .ForMember(user => user.USER_NAME, map => map.MapFrom(client => client.FIRST_NAME + " " + client.LAST_NAME))
                .ForMember(user => user.USER_FIRST_NAME, map => map.MapFrom(client => client.FIRST_NAME))
                .ForMember(user => user.USER_LAST_NAME, map => map.MapFrom(client => client.LAST_NAME))
                .ForMember(user => user.BIRTH_DATE, map => map.MapFrom(client => client.BIRTH_DATE))
                .ForMember(user => user.CREATE_DATE, map => map.MapFrom(client => client.CREATE_DATE))
                .ForMember(user => user.UPDATE_DATE, map => map.MapFrom(client => client.UPDATE_DATE));
        }
    }
}
