﻿using Microsoft.EntityFrameworkCore;
using AdminSync.Entity.CPAdmin;

namespace AdminSync.DBContext
{
    public class CPAdminContext : DbContext
    {
        public DbSet<UserData> UserData { get; set; }

        public CPAdminContext(DbContextOptions<CPAdminContext> dbContextOptions) : base(dbContextOptions)
        {
        }
    }
}
