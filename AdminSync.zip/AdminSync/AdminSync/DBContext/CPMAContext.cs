﻿using Microsoft.EntityFrameworkCore;
using AdminSync.Entity.CPMA;

namespace AdminSync.DBContext
{
    public class CPMAContext : DbContext
    {
        public DbSet<UserRegistration> UserRegistration { get; set; }

        public CPMAContext(DbContextOptions<CPMAContext> dbContextOptions) : base(dbContextOptions)
        {
        }
    }
}
