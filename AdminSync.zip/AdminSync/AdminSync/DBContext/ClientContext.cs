﻿using Microsoft.EntityFrameworkCore;
using AdminSync.Entity.Client;

namespace AdminSync.DBContext
{
    public class ClientContext : DbContext
    {
        public DbSet<ClientData> ClientData { get; set; }

        public ClientContext(DbContextOptions<ClientContext> dbContextOptions) : base(dbContextOptions)
        {
        }
    }
}
