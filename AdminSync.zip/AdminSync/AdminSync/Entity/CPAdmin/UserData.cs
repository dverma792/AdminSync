﻿using System.ComponentModel.DataAnnotations;

namespace AdminSync.Entity.CPAdmin
{
    public class UserData
    {
        [Key]
        public string USER_ID { get; set; }

        public string USER_NAME { get; set; } = string.Empty;

        public string USER_FIRST_NAME { get; set; } = string.Empty;

        public string USER_LAST_NAME { get; set; } = string.Empty;

        public DateTime BIRTH_DATE { get; set; }

        public DateTime CREATE_DATE { get; set; }

        public DateTime UPDATE_DATE { get; set; }
    }
}
