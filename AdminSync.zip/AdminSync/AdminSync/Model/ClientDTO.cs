﻿namespace AdminSync.Model
{
    public class ClientDTO
    {
        public string USER_ID { get; set; } = string.Empty;

        public string CIF_CLIENT_NO { get; set; } = string.Empty;

        public string TITLE { get; set; } = string.Empty;

        public string FIRST_NAME { get; set; } = string.Empty;

        public string LAST_NAME { get; set; } = string.Empty;

        public DateTime BIRTH_DATE { get; set; }

        public DateTime CREATE_DATE { get; set; }

        public DateTime UPDATE_DATE { get; set; }
    }
}
