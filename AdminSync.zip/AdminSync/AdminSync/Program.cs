﻿using AdminSync.DBContext;
using AdminSync.Resync;
using AdminSync.Resync.Services;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace AdminSync
{
    public class Program
    {
        static void Main()
        {
            var serviceProvider = ConfigureServices();
            var loadService = serviceProvider.GetService<IResyncService>();
            loadService.ResyncClientAdmin();
        }
        public static ServiceProvider ConfigureServices()
        {
            var serviceCollection = new ServiceCollection();

            IConfiguration _configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", false, false)
                .Build();

            serviceCollection.AddAutoMapper(typeof(AutoMapperConfigurator));

            serviceCollection.AddDbContext<ClientContext>(options =>
                options.UseSqlServer(_configuration.GetConnectionString("Client")));

            serviceCollection.AddDbContext<CPAdminContext>(options =>
                options.UseSqlServer(_configuration.GetConnectionString("CPAdmin")));

            serviceCollection.AddDbContext<CPMAContext>(options =>
                options.UseSqlServer(_configuration.GetConnectionString("CPMA")));

            serviceCollection.AddScoped<IResyncService, ResyncService>(container => new ResyncService(container.GetService<ClientContext>(),
                                                                                                      container.GetService<CPAdminContext>(),
                                                                                                      container.GetService<CPMAContext>(),
                                                                                                      container.GetService<IMapper>()));
            
            return serviceCollection.BuildServiceProvider();
        }
    }
}