﻿namespace AdminSync.Resync
{
    public interface IResyncService
    {
        void ResyncClientAdmin();
    }
}
