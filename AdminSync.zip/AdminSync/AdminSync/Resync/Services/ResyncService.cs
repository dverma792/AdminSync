﻿using AdminSync.DBContext;
using AdminSync.Entity.Client;
using AdminSync.Entity.CPAdmin;
using AdminSync.Model;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace AdminSync.Resync.Services
{
    public class ResyncService : IResyncService
    {
        private readonly ClientContext _contextClient;
        private readonly CPAdminContext _contextCPAdmin;
        private readonly CPMAContext _contextCPMA;
        private readonly IMapper _mapper;
        public ResyncService(ClientContext contextClient,
                             CPAdminContext contextCPAdmin,
                             CPMAContext contextCPMA,
                             IMapper mapper)
        {
            _contextClient = contextClient;
            _contextCPAdmin = contextCPAdmin;
            _contextCPMA = contextCPMA;
            _mapper = mapper;
        }
        public void ResyncClientAdmin()
        {
            try
            {
                List<UserData> userData = new List<UserData>();

                var clients = _contextClient.ClientData.ToList();

                Console.Write("Total number of Clients exists in Client database: {0}\n", clients.Count);

                var clientDTO = GetClientsWithUserID(clients);


                foreach (var client in _contextCPAdmin.UserData.AsNoTrackingWithIdentityResolution().ToList())
                {
                    var user = clientDTO.FirstOrDefault(x => x.USER_ID == client.USER_ID);
                    if (user != null)
                        userData.Add(_mapper.Map<ClientDTO, UserData>(user));
                }

                _contextCPAdmin.UpdateRange(userData);

                _contextCPAdmin.SaveChanges();

                Console.Write("Total number of records updated in CPAdmin are {0}\n", userData.Count);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An exception occurs while updating data in CPAdmin database.");
            }
        }

        private IList<ClientDTO> GetClientsWithUserID(List<ClientData> clients)
        {
            return clients.Join(
                                 _contextCPMA.UserRegistration,
                                 client => client.CIF_CLIENT_NO,
                                 user => user.CIF_CLIENT_NO,
                                 (client, user) => new ClientDTO
                                 {
                                     CIF_CLIENT_NO = client.CIF_CLIENT_NO,
                                     TITLE = client.TITLE,
                                     FIRST_NAME = client.FIRST_NAME,
                                     LAST_NAME = client.LAST_NAME,
                                     BIRTH_DATE = client.BIRTH_DATE,
                                     CREATE_DATE = client.CREATE_DATE,
                                     UPDATE_DATE = DateTime.Now,
                                     USER_ID = user.USER_ID
                                 }).ToList();
        }
    }
}
